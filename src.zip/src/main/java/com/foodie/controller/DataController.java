package com.foodie.controller;

import com.foodie.entity.Restaurant;
import com.foodie.entity.Dish;
import com.foodie.repository.RestaurantRepository;
import com.foodie.repository.DishRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class DataController {

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private DishRepository dishRepository;

    @PostMapping("/seed-data")
    public ResponseEntity<Map<String, Object>> seedData() {
        // Clear existing data
        dishRepository.deleteAll();
        restaurantRepository.deleteAll();

        // Create restaurants
        List<Restaurant> restaurants = new ArrayList<>();

        Restaurant pizzaPalace = new Restaurant();
        pizzaPalace.setName("Pizza Palace");
        pizzaPalace.setCuisineType("Italian");
        pizzaPalace.setAddress("123 Main St, Downtown");
        pizzaPalace.setPhone("+1-555-0101");
        pizzaPalace.setEmail("info@pizzapalace.com");
        pizzaPalace.setDeliveryTimeMin(30);
        pizzaPalace.setDeliveryFee(new BigDecimal("2.99"));
        pizzaPalace.setRating(new BigDecimal("4.5"));
        pizzaPalace.setIsActive(true);
        restaurants.add(pizzaPalace);

        Restaurant burgerBarn = new Restaurant();
        burgerBarn.setName("Burger Barn");
        burgerBarn.setCuisineType("American");
        burgerBarn.setAddress("456 Oak Ave, Midtown");
        burgerBarn.setPhone("+1-555-0202");
        burgerBarn.setEmail("hello@burgerbarn.com");
        burgerBarn.setDeliveryTimeMin(25);
        burgerBarn.setDeliveryFee(new BigDecimal("3.49"));
        burgerBarn.setRating(new BigDecimal("4.2"));
        burgerBarn.setIsActive(true);
        restaurants.add(burgerBarn);

        Restaurant sushiSpot = new Restaurant();
        sushiSpot.setName("Sushi Spot");
        sushiSpot.setCuisineType("Japanese");
        sushiSpot.setAddress("789 Pine Rd, Uptown");
        sushiSpot.setPhone("+1-555-0303");
        sushiSpot.setEmail("orders@sushispot.com");
        sushiSpot.setDeliveryTimeMin(40);
        sushiSpot.setDeliveryFee(new BigDecimal("4.99"));
        sushiSpot.setRating(new BigDecimal("4.8"));
        sushiSpot.setIsActive(true);
        restaurants.add(sushiSpot);

        Restaurant tacoTown = new Restaurant();
        tacoTown.setName("Taco Town");
        tacoTown.setCuisineType("Mexican");
        tacoTown.setAddress("321 Elm St, Southside");
        tacoTown.setPhone("+1-555-0404");
        tacoTown.setEmail("info@tacotown.com");
        tacoTown.setDeliveryTimeMin(20);
        tacoTown.setDeliveryFee(new BigDecimal("1.99"));
        tacoTown.setRating(new BigDecimal("4.3"));
        tacoTown.setIsActive(true);
        restaurants.add(tacoTown);

        // Save restaurants
        List<Restaurant> savedRestaurants = restaurantRepository.saveAll(restaurants);

        // Create dishes for each restaurant
        List<Dish> dishes = new ArrayList<>();

        // Pizza Palace dishes
        Long pizzaPalaceId = savedRestaurants.get(0).getId();
        dishes.add(createDish("Margherita Pizza", "Classic tomato, mozzarella, basil", new BigDecimal("12.99"), pizzaPalaceId, true, false, false));
        dishes.add(createDish("Pepperoni Pizza", "Tomato sauce, mozzarella, pepperoni", new BigDecimal("14.99"), pizzaPalaceId, false, false, false));
        dishes.add(createDish("Veggie Supreme", "Mixed vegetables, cheese", new BigDecimal("13.99"), pizzaPalaceId, true, true, false));

        // Burger Barn dishes
        Long burgerBarnId = savedRestaurants.get(1).getId();
        dishes.add(createDish("Classic Burger", "Beef patty, lettuce, tomato, onion", new BigDecimal("9.99"), burgerBarnId, false, false, false));
        dishes.add(createDish("Chicken Burger", "Grilled chicken breast, avocado", new BigDecimal("10.99"), burgerBarnId, false, false, false));
        dishes.add(createDish("Veggie Burger", "Plant-based patty, vegan cheese", new BigDecimal("11.99"), burgerBarnId, true, true, false));

        // Sushi Spot dishes
        Long sushiSpotId = savedRestaurants.get(2).getId();
        dishes.add(createDish("Salmon Roll", "Fresh salmon, cucumber, avocado", new BigDecimal("8.99"), sushiSpotId, false, false, true));
        dishes.add(createDish("Tuna Sashimi", "Fresh tuna, wasabi, ginger", new BigDecimal("12.99"), sushiSpotId, false, false, true));
        dishes.add(createDish("Veggie Roll", "Cucumber, avocado, carrot", new BigDecimal("6.99"), sushiSpotId, true, true, true));

        // Taco Town dishes
        Long tacoTownId = savedRestaurants.get(3).getId();
        dishes.add(createDish("Beef Tacos", "Seasoned beef, lettuce, cheese", new BigDecimal("7.99"), tacoTownId, false, false, true));
        dishes.add(createDish("Chicken Quesadilla", "Grilled chicken, cheese, peppers", new BigDecimal("8.99"), tacoTownId, false, false, false));
        dishes.add(createDish("Black Bean Burrito", "Black beans, rice, vegetables", new BigDecimal("9.99"), tacoTownId, true, true, false));

        // Save dishes
        dishRepository.saveAll(dishes);

        return ResponseEntity.ok(Map.of(
            "message", "Database seeded successfully",
            "restaurantsCreated", savedRestaurants.size(),
            "dishesCreated", dishes.size()
        ));
    }

    private Dish createDish(String name, String description, BigDecimal price, Long restaurantId, 
                           boolean vegetarian, boolean vegan, boolean glutenFree) {
        Dish dish = new Dish();
        dish.setName(name);
        dish.setDescription(description);
        dish.setPrice(price);
        dish.setRestaurantId(restaurantId);
        dish.setIsVegetarian(vegetarian);
        dish.setIsVegan(vegan);
        dish.setIsGlutenFree(glutenFree);
        dish.setIsAvailable(true);
        return dish;
    }

    @GetMapping("/restaurants-count")
    public ResponseEntity<Map<String, Object>> getRestaurantsCount() {
        long count = restaurantRepository.count();
        return ResponseEntity.ok(Map.of(
            "count", count,
            "message", count > 0 ? "Restaurants available" : "No restaurants found - consider seeding data"
        ));
    }
}