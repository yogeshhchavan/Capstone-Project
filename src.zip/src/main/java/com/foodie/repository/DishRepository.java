package com.foodie.repository;

import com.foodie.entity.Dish;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface DishRepository extends JpaRepository<Dish, Long> {
    
    List<Dish> findByRestaurantIdAndIsAvailableTrue(Long restaurantId);
    
    List<Dish> findByCategoryContainingIgnoreCase(String category);
    
    List<Dish> findByIsVegetarianTrue();
    
    List<Dish> findByIsVeganTrue();
    
    @Query("SELECT d FROM Dish d WHERE d.restaurantId = :restaurantId AND d.isAvailable = true AND " +
           "(:category IS NULL OR d.category ILIKE %:category%) AND " +
           "(:isVegetarian IS NULL OR d.isVegetarian = :isVegetarian) AND " +
           "(:minPrice IS NULL OR d.price >= :minPrice) AND " +
           "(:maxPrice IS NULL OR d.price <= :maxPrice)")
    Page<Dish> findFilteredDishes(@Param("restaurantId") Long restaurantId,
                                 @Param("category") String category,
                                 @Param("isVegetarian") Boolean isVegetarian,
                                 @Param("minPrice") BigDecimal minPrice,
                                 @Param("maxPrice") BigDecimal maxPrice,
                                 Pageable pageable);
    
    @Query("SELECT d FROM Dish d WHERE d.isAvailable = true AND d.name ILIKE %:name%")
    List<Dish> findByNameContainingIgnoreCase(@Param("name") String name);
    
    @Query("SELECT d FROM Dish d WHERE d.isAvailable = true ORDER BY d.rating DESC")
    List<Dish> findTopRatedDishes(Pageable pageable);
}