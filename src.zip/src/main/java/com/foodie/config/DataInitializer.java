package com.foodie.config;

import com.foodie.entity.Restaurant;
import com.foodie.entity.Dish;
import com.foodie.repository.RestaurantRepository;
import com.foodie.repository.DishRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private DishRepository dishRepository;

    @Override
    public void run(String... args) throws Exception {
        // Only initialize if no data exists
        if (restaurantRepository.count() == 0) {
            initializeData();
        }
    }

    private void initializeData() {
        // Create Pizza Palace
        Restaurant pizzaPalace = new Restaurant();
        pizzaPalace.setName("Pizza Palace");
        pizzaPalace.setDescription("Authentic Italian pizzas with fresh ingredients");
        pizzaPalace.setCuisineType("Italian");
        pizzaPalace.setAddress("123 Main St, Downtown");
        pizzaPalace.setPhone("+1-555-0101");
        pizzaPalace.setEmail("info@pizzapalace.com");
        pizzaPalace.setDeliveryTimeMin(25);
        pizzaPalace.setDeliveryTimeMax(35);
        pizzaPalace.setDeliveryFee(new BigDecimal("2.99"));
        pizzaPalace.setMinimumOrder(new BigDecimal("15.00"));
        pizzaPalace.setRating(new BigDecimal("4.5"));
        pizzaPalace.setIsActive(true);
        restaurantRepository.save(pizzaPalace);

        // Create Burger Barn
        Restaurant burgerBarn = new Restaurant();
        burgerBarn.setName("Burger Barn");
        burgerBarn.setDescription("Juicy burgers and crispy fries");
        burgerBarn.setCuisineType("American");
        burgerBarn.setAddress("456 Oak Ave, Midtown");
        burgerBarn.setPhone("+1-555-0202");
        burgerBarn.setEmail("hello@burgerbarn.com");
        burgerBarn.setDeliveryTimeMin(20);
        burgerBarn.setDeliveryTimeMax(30);
        burgerBarn.setDeliveryFee(new BigDecimal("3.49"));
        burgerBarn.setMinimumOrder(new BigDecimal("12.00"));
        burgerBarn.setRating(new BigDecimal("4.2"));
        burgerBarn.setIsActive(true);
        restaurantRepository.save(burgerBarn);

        // Create Sushi Spot
        Restaurant sushiSpot = new Restaurant();
        sushiSpot.setName("Sushi Spot");
        sushiSpot.setDescription("Fresh sushi and Japanese delicacies");
        sushiSpot.setCuisineType("Japanese");
        sushiSpot.setAddress("789 Pine Rd, Uptown");
        sushiSpot.setPhone("+1-555-0303");
        sushiSpot.setEmail("orders@sushispot.com");
        sushiSpot.setDeliveryTimeMin(35);
        sushiSpot.setDeliveryTimeMax(45);
        sushiSpot.setDeliveryFee(new BigDecimal("4.99"));
        sushiSpot.setMinimumOrder(new BigDecimal("20.00"));
        sushiSpot.setRating(new BigDecimal("4.8"));
        sushiSpot.setIsActive(true);
        restaurantRepository.save(sushiSpot);

        // Create Taco Town
        Restaurant tacoTown = new Restaurant();
        tacoTown.setName("Taco Town");
        tacoTown.setDescription("Authentic Mexican tacos and burritos");
        tacoTown.setCuisineType("Mexican");
        tacoTown.setAddress("321 Elm St, Southside");
        tacoTown.setPhone("+1-555-0404");
        tacoTown.setEmail("info@tacotown.com");
        tacoTown.setDeliveryTimeMin(15);
        tacoTown.setDeliveryTimeMax(25);
        tacoTown.setDeliveryFee(new BigDecimal("1.99"));
        tacoTown.setMinimumOrder(new BigDecimal("10.00"));
        tacoTown.setRating(new BigDecimal("4.3"));
        tacoTown.setIsActive(true);
        restaurantRepository.save(tacoTown);

        System.out.println("✅ Sample restaurant data initialized successfully!");
    }
}