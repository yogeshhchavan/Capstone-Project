package com.foodie.service;

import com.foodie.dto.RestaurantDto;
import com.foodie.entity.Restaurant;
import com.foodie.repository.RestaurantRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RestaurantService {
    
    private final RestaurantRepository restaurantRepository;

    public RestaurantService(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }
    
    public Restaurant createRestaurant(RestaurantDto restaurantDto) {
        Restaurant restaurant = new Restaurant();
        mapDtoToEntity(restaurantDto, restaurant);
        return restaurantRepository.save(restaurant);
    }
    
    public Optional<Restaurant> findById(Long id) {
        return restaurantRepository.findById(id);
    }
    
    public List<Restaurant> findActiveRestaurants() {
        return restaurantRepository.findByIsActiveTrue();
    }
    
    public Restaurant updateRestaurant(Long id, RestaurantDto restaurantDto) {
        Restaurant restaurant = restaurantRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Restaurant not found"));
        mapDtoToEntity(restaurantDto, restaurant);
        return restaurantRepository.save(restaurant);
    }
    
    public void deleteRestaurant(Long id) {
        Restaurant restaurant = restaurantRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Restaurant not found"));
        restaurant.setIsActive(false);
        restaurantRepository.save(restaurant);
    }
    
    public List<Restaurant> searchRestaurantsByName(String name) {
        return restaurantRepository.findByNameContainingIgnoreCase(name);
    }
    
    public List<Restaurant> findByCuisineType(String cuisineType) {
        return restaurantRepository.findByCuisineTypeContainingIgnoreCase(cuisineType);
    }
    
    public Page<Restaurant> findFilteredRestaurants(String cuisineType, Double minRating, Pageable pageable) {
        return restaurantRepository.findFilteredRestaurants(cuisineType, minRating, pageable);
    }
    
    public List<Restaurant> getTopRatedRestaurants(int limit) {
        return restaurantRepository.findTopRatedRestaurants(Pageable.ofSize(limit));
    }
    
    private void mapDtoToEntity(RestaurantDto dto, Restaurant entity) {
        entity.setName(dto.getName());
        entity.setDescription(dto.getDescription());
        entity.setAddress(dto.getAddress());
        entity.setPhone(dto.getPhone());
        entity.setEmail(dto.getEmail());
        entity.setCuisineType(dto.getCuisineType());
        entity.setDeliveryTimeMin(dto.getDeliveryTimeMin());
        entity.setDeliveryTimeMax(dto.getDeliveryTimeMax());
        entity.setDeliveryFee(dto.getDeliveryFee());
        entity.setMinimumOrder(dto.getMinimumOrder());
        entity.setIsActive(dto.getIsActive() != null ? dto.getIsActive() : true);
        entity.setImageUrl(dto.getImageUrl());
        entity.setOpeningTime(dto.getOpeningTime());
        entity.setClosingTime(dto.getClosingTime());
    }
}